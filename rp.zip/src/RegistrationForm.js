import React, { useState } from 'react';

const RegistrationForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [age, setAge] = useState('');
  const [state, setState] = useState('');
  const [zipcode, setZipcode] = useState('');
  const [country, setCountry] = useState('');
  const [errors, setErrors] = useState({});

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    switch (name) {
      case 'name':
        setName(value);
        break;
      case 'email':
        setEmail(value);
        break;
      case 'password':
        setPassword(value);
        break;
      case 'confirmPassword':
        setConfirmPassword(value);
        break;
      case 'age':
        setAge(value);
        break;
      case 'state':
        setState(value);
        break;
      case 'zipcode':
        setZipcode(value);
        break;
      case 'country':
        setCountry(value);
        break;
      default:
        break;
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = {};
    if (!name) {
      errors.name = 'Please fill out the name field.';
    }
    if (!email) {
      errors.email = 'Please fill out the email field.';
    }
    if (!password) {
      errors.password = 'Please fill out the password field.';
    }
    if (!confirmPassword) {
      errors.confirmPassword = 'Please fill out the confirm password field.';
    }
    if (!age) {
      errors.age = 'Please fill out the age field.';
    }
    if (!state) {
      errors.state = 'Please fill out the state field.';
    }
    if (!zipcode) {
      errors.zipcode = 'Please fill out the zipcode field.';
    }
    if (!country) {
      errors.country = 'Please fill out the country field.';
    }
    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
    // send form data to server
    // ...
  };

  return (
    <div className="registration-form">
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input type="text" name="name" value={name} onChange={handleInputChange} />
          {errors.name && (
            <div className="error-message">{errors.name}</div>
          )}
        </label>
        <label>
          Email:
          <input type="email" name="email" value={email} onChange={handleInputChange} />
          {errors.email && (
            <div className="error-message">{errors.email}</div>
          )}
        </label>
        <label>
          Age:
          <input type="number" name="age" value={age} onChange={handleInputChange} pattern="[0-9]+" />
          {errors.age && (
            <div className="error-message">{errors.age}</div>
          )}
        </label>
        <label>
          State:
          <input type="text" name="state" value={state} onChange={handleInputChange} />
          {errors.state && (
            <div className="error-message">{errors.state}</div>
          )}
        </label>
        <label>
          Zipcode:
          <input type="text" name="zipcode" value={zipcode} onChange={handleInputChange} />
          {errors.zipcode && (
            <div className="error-message">{errors.zipcode}</div>
          )}
        </label>
        <label>
          Country:
          <input type="text" name="country" value={country} onChange={handleInputChange} />
          {errors.country && (
            <div className="error-message">{errors.country}</div>
          )}
        </label>
        <button type="submit">Register</button>
      </form>
      <p>Already a member? <span onClick={() => window.location.href = '#'}>LOGIN</span></p>
    </div>
  );
};

export default RegistrationForm;
