import React from 'react';
import ReactDOM from 'react-dom';
import RegistrationForm from './RegistrationForm';
import './rpstyle.css';

ReactDOM.render(
  <React.StrictMode>
    <RegistrationForm />
  </React.StrictMode>,
  document.getElementById('root')
);